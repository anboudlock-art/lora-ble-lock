# LoRa-BLE智能锁固件

## 项目简介

基于SYD8811芯片的蓝牙锁项目，集成E220-900T22S LoRa模块，实现远程控制功能。

## 功能特性

- ✅ LoRa远程通信（E220-900T22S模块）
- ✅ 蓝牙BLE配对和控制
- ✅ 开锁/上锁/剪断报警
- ✅ 状态上报
- ✅ 低功耗设计

## 硬件要求

- 主控芯片：SYD8811 (ARM Cortex-M0)
- LoRa模块：E220-900T22S
- 电源：3.3V

## 编译环境

- IDE：Keil MDK v5.43
- 编译器：ARM Compiler v6.19 (ARMCLANG)
- CMSIS：5.9.0

## 快速开始

### 1. 克隆仓库

```bash
git clone https://github.com/anboudlock-art/lora-ble-lock.git
cd lora-ble-lock
```

### 2. 编译固件

#### Windows用户：

```bash
cd firmware/keil
# 双击打开 SYD8811_BLE_LoRa_Lock_V01.uvprojx
# 或运行编译脚本
../tools/compile_lora.bat
```

#### 手动编译：

1. 打开Keil uVision5
2. 打开工程：`firmware/keil/SYD8811_BLE_LoRa_Lock_V01.uvprojx`
3. 按F7编译
4. 查看输出：`firmware/keil/output/Ble_Vendor_Service.hex`

## 目录结构

```
lora-ble-lock/
├── firmware/          # 固件源代码
│   ├── src/          # C源文件
│   ├── include/      # 头文件
│   └── keil/         # Keil工程
├── tools/            # 工具脚本
├── docs/             # 文档
└── examples/         # 示例代码
```

## 版本历史

### v1.0.0 (2024-04-01)
- 初始版本
- 支持LoRa通信
- 支持蓝牙BLE

## 许可证

MIT License

## 联系方式

- GitHub: [@anboudlock-art](https://github.com/anboudlock-art)
